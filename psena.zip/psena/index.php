
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="img/icono1.png">
    
    <title>Login</title>
</head>
<body>
    <section>

    <div class="login-box">
        <form action="validar.php" method="post">            
            <h1>Login</h1>
            <div>
            <!--usuario-->                 
            <p><span class="icon"><ion-icon name="mail"></ion-icon></span> 
            <input type="text" name="usuario"><label>Email</label></p>            
            <!--Contraseña-->
            <p><span class="icon"><ion-icon name="lock-open"></ion-icon></span> 
            <input type="password" name="contrasena"><label>Password</label></p>
            </div>               
            <!--Botón-->
        <button type="submit">Iniciar</button>        
        </form>
    </div>

    </section>
    <!--script-->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>   
</body>
</html>