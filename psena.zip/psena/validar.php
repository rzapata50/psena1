<?php
$usuario=$_POST['usuario'];
$contrasena=$_POST['contrasena'];

session_start();
$_SESSION['usuario']=$usuario;

include('db.php');

$consulta="SELECT * FROM usuario WHERE usuario='$usuario' and contrasena='$contrasena'";
$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_num_rows($resultado);

if($filas){
    header("location:activarpc.php");
}else{
    ?>
    <?php
    include("../psena/index.php");
    ?>
    <h3 class="bold">ERROR DE AUTENTICACION</h3>
    <?php
}
mysqli_free_result($resultado);
mysqli_close($conexion);
?>
