<?php
$host = "localhost";
$user = "root";
$clave = "";
$bd = "psena";

$conectar = new mysqli($host, $user, $clave, $bd)
?>