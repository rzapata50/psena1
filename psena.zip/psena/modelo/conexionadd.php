<?php
$host = "localhost";
$user = "root";
$clave = "Inn0v4c10n*";
$bd = "psena";

$conectar = new mysqli($host, $user, $clave, $bd)
?>