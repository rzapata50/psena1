<!--Conexion del boton Editar-->

<?php
$nombrebd = "psena";
$usuario = "root";
$clave = "";
try{
	$bd = new PDO('mysql:host=localhost; dbname=' .$nombrebd, $usuario, $clave,
	array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch(Exception $e){
	
	echo "<script> alert('Error de Conexion a bd');</script>".$e->getMessage();
}

?>
