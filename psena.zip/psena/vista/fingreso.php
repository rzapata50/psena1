<!--validacion de pagina-->
<?php
session_start();
if (!isset($_SESSION['usuario'])){
  header('location: http://localhost/psena/index.php');
}
?>

<!--formato de conexion con bd-->
<?php
include_once '../modelo/conexionfiltrar.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$consulta = "SELECT * FROM programa";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$usuarios = $resultado->fetchALL(PDO::FETCH_ASSOC);
?>
<!--formato de HTML-->
<!Doctype html>
<html lang="es">
    <head>
        <title>Registro</title>
        <link rel="shortcut icon" href="../img/icono1.png">
        <!--conexion bootstrap-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" 
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
        <!--alerta de formulario--> 
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>        
      </head>
    <!--contenedor de navbar-->
    <body>        
    <nav class="navbar  navbar-expand-lg bg-success">      
    <div class="container-fluid">
    <img src="../img/icono1.png" width="5%">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active text-white" aria-current="page" href="../activarpc.php">Inicio</a>
          </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="fingreso.php">Registrarse</a>
        </li>        
        <li class="nav-item">
          <a class="nav-link text-white" href="fconsulta.php">Consulta</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="listado.php">Listado</a>
        </li>
      </ul>      
    </div>
  </div>
</nav><br>

<!-- contenedor grande de columnas-->
<div class="container text-center">
  <div class="row">
    <div class="col">

        <!--formulario de Registro-->
        <form action="" method="post">
            <div class="card" style="width: 50rem;">
            <div class="card-header bg-danger text-white">
                Formulario de Registro
            </div>
            <div class="container text-center">

            <!--contenedor de columnas pequeño-->
            <div class="row">
                <div class="col">                  
                  <label>Numero de Documento</label>
                  <input type="number" name="Documento" placeholder="Numero de Cedula" class="form-control"><br>
                  <label>Nombres Completos</label>
                  <input type="text" name="Nombres" placeholder="Nombres y Apellidos" class="form-control"><br>

                  <!--contendor de seleccion-->
                  <label>Rol en la Universidad</label>
                  <select name="Rol" class="form-control">
                    <option>--Seleccione--</option>
                    <option>Estudiante</option>
                    <option>Docente</option>
                    <option>Administrativo</option>
                    <option>Egresado</option>
                  </select><br>
                </div><br>

                <!--contenedor de columnas pequeño-->
                <div class="col">
                  <label>Código del Programa</label>
                  <select name="Idprograma" class="form-control">
                  <option>--Seleccione--</option>
                  <?php
                    foreach($usuarios as $filtro){
                        ?>
                        <option><?php echo $filtro['Idprograma']?> -- <?php echo $filtro['Nombreprograma']?></option></option>                    
                    <?php
                    }
                    ?>      
                  </select><br>
                  <label>Nombre del Programa</label>
                  <select name="Nombreprograma" class="form-control">
                    <option>--Seleccione--</option>
                    <?php
                    foreach($usuarios as $filtro){
                        ?>
                        <option><?php echo $filtro['Nombreprograma']?></option>                     
                    <?php
                    }
                    ?>                   
                  </select><br>  
                  <label>Correo</label>
                  <input type="email" name="Correo" placeholder="Email Usuario" class="form-control"><br>                                                
                </div>
                
                <!--boton-->
                <div>
                    <input type="submit" name="btn_enviar" class="btn btn-light" value="ENVIAR">
                </div>
              </div>            
            </div><br>

            <!-- Controlador de Registro -->
            <?php
            include("../modelo/conexionadd.php");

            if(isset($_POST['btn_enviar']))
            {
                $documento = $_POST['Documento'];
                $nombres = $_POST['Nombres'];
                $rol = $_POST['Rol'];
                $idprograma = $_POST['Idprograma'];
                $nombreprograma = $_POST['Nombreprograma'];
                $email = $_POST['Correo'];
                

                if($documento=="" || $nombres=="" || $rol=="" || $idprograma=="" || $nombreprograma=="" || $email=="")
                {
                    echo "<script> Swal.fire('Todos los campos son obligatorios')</script>";
                }
                else
                {
                  $query = mysqli_query($conectar, "INSERT INTO registro (Documento, Nombres, Rol, Idprograma, Nombreprograma, Correo) 
                  values ('$documento', '$nombres', '$rol', '$idprograma', '$nombreprograma', '$email')"); 
                  {
                    echo "<script> Swal.fire('Registro Exitoso')</script>";
                  }
                }
            }
            ?>
        </form>      
    </div>    
  </div>
</div>

    </body>
</html>