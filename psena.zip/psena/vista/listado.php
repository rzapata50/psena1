<!--validacion de pagina-->
<?php
session_start();
if (!isset($_SESSION['usuario'])){
  header('location: http://localhost/psena/index.php');
}
?>

<!--formato de conexion con bd-->
<?php
include_once '../modelo/conexionfiltrar.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$consulta = "SELECT * FROM registro";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$usuarios = $resultado->fetchALL(PDO::FETCH_ASSOC);
?>



<!--formato de HTML-->
<!Doctype html>
<html lang="es">
    <head>
        <title>Listado</title>
        <link rel="shortcut icon" href="../img/icono1.png"> 
        
        <!-- ESTILOS  DATATABLES-->
        <link rel="stylesheet" href="../datatables/datatables.min.css">
        <link rel="stylesheet" type="text/css" href="../datatables/css/dataTables.bootstrap4.min.css">                
        <!--SCRIPT DE BOOTSTRAP-->
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" 
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        
        <link src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" 
        rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>  
              
        <!--conexion de iconos-->
        <script src="https://kit.fontawesome.com/dcb1bbced2.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://kit.fontawesome.com/dcb1bbced2.css" crossorigin="anonymous">
        <!--alerta de formulario--> 
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>        
        <!--conexion bootstrap--> 
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
 
    </head>
   
    <!--contenedor de navbar-->
    <body>        
    <nav class="navbar navbar-expand-lg bg-success">      
    <div class="container-fluid">
    <img src="../img/icono1.png" width="5%">

    <!--Boton de alerta-->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active text-white" aria-current="page" href="../activarpc.php">Inicio</a>
          </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="fingreso.php">Registrarse</a>
        </li>        
        <li class="nav-item">
          <a class="nav-link text-white" href="fconsulta.php">Consulta</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="listado.php">Listado</a>
        </li>
      </ul>      
    </div>
  </div>
</nav>
<br><br>

<!--contenedor de la tabla filas y columnas-->
<div class="container">
        <h1 class="text-center text-dark">Historial de Usuarios Registrados</h1>
        <br><center>
            <br>
            <table id="usuarios" class="table-striped table-success" style="width: 100%;">
                <thead>
                    <tr>
                        <th scope="col"><center>Item</center></th>
                        <th scope="col"><center>Documento</center></th>
                        <th scope="col"><center>Nombres</center></th>
                        <th scope="col"><center>Rol</center></th>
                        <th scope="col"><center>Código del Programa</center></th>
                        <th scope="col"><center>Nombre del Programa</center></th>
                        <th scope="col"><center>Correo</center></th>
                                <th scope="col"><center>Editar</center></th>
                                <th scope="col"><center>Eliminar</center></th>
                    </tr>
                </thead>

            <!-- Logica para filtrar datos de la tabla registro -->
            <tbody>
                <?php
                foreach($usuarios as $filtro){
                ?>
                <tr>
                    <td><center><?php echo $filtro['id']?></center></td>
                    <td><center><?php echo $filtro['Documento']?></center></td>
                    <td><center><?php echo $filtro['Nombres']?></center></td>
                    <td><center><?php echo $filtro['Rol']?></center></td>
                    <td><center><?php echo $filtro['Idprograma']?></center></td>
                    <td><center><?php echo $filtro['Nombreprograma']?></center></td>
                    <td><center><?php echo $filtro['Correo']?></center></td>

                    

                    <!-- Boton de editar -->
                    <td><button type="button" class="btn btn-primary editbtn" data-bs-toggle="modal" 
                    data-bs-target="#editar"><i class="fa-solid fa-file-pen"></i></button></td>

                    <!-- Boton de eliminar -->
                    <td><button type="button" class="btn btn-warning deletebtn" data-bs-toggle="modal" 
                    data-bs-target="#eliminar"><i class="fa-solid fa-delete-left"></i></button></td>
                </tr>
                <?php
                }
                ?>       
            </tbody>   
        </table>
    </center>
</div>
<!--- Modal de Editar --->
<div class="modal fade" id="editar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width: 80rem;">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5">Actualizar Datos del Usuario</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <!--conectar con el controlador del boton-->
        <div class="modal-body">
            <form action="../controlador/editar.php" method="post">
            <input type="hidden" name="id" id="update_id">	

            <!--contenedor-->	   
	<div class="container text-center">
        <div class="row">
            <div class="col-6">				
                <div class="form-group">
                    <label>Numero Documento</label>
                    <input type="number" name="Documento" id="documento" class="form-control">
                </div>
            
                <div class="form-group">
                    <label>Nombres Completos</label>
                    <input type="text" name="Nombres" id="nombres"  class="form-control">
                </div>
            
                <div class="form-group">
                    <label>Rol en la Universidad</label>
                    <select name="Rol" id="tiporol" class="form-control">
                        <option>---Seleccione---</option>
                        <option>Estudiante</option>
                        <option>Docente</option>
                        <option>Administrativo</option>
                        <option>Egresado</option>
                    </select>
                </div>
		    </div>			
            <div class="col-6">
	            <div class="form-group">
			        <label>Codigo de Programa</label>
                <select name="Idprograma"  id="Idprograma" class="form-control">
                    <option>---Seleccione---</option>
                          <?php
                          foreach($usuarios as $filtro){
                          ?>
                          <option><?php echo $filtro['Idprograma']?> -- <?php echo $filtro['Nombreprograma']?></option>                        
                          <?php
                          }
                          ?>
                </select>
		        </div>                        
	            <div class="form-group">
			        <label>Nombre del Programa</label>
			        <select name="Nombreprograma" id="Nombreprograma" class="form-control">
			            <option>---Seleccione---</option>                        
                        <?php
                        foreach($usuarios as $filtro){
                            ?>
                        <option><?php echo $filtro['Nombreprograma']?></option>                        
                        <?php
                        }
                        ?>
			        </select>
		        </div>	
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="Correo" id="email"  class="form-control">
                </div>	    
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-success">Actualizar</button>
                </div>
            </div>
        </div>
    </div>
		    </form>
        </div> 	
    </div>
  </div>
</div>

<!--- Modal de Eliminar --->
<div class="modal fade" id="eliminar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width: 80rem;">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar Datos del Usuario</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
        <div class="modal-body">
        <h3 class="text-danger" id="exampleModalLabel">Se elminará la Información Existente ¿Desea Continuar?</h3>
            <form action="../controlador/eliminar.php" method="post">
            <input type="hidden" name="id" id="delete_id">
        </div>
                <!--Botón-->
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-success">Eliminar</button>
                </div>
            </div>
        </div>
    </div>
		    </form>
        </div>	
    </div>
  </div>
</div>
<br><br>
 
<!--popper bootstrap-->
<script type="text/javascript" src="../jquery/jquery-3.3.1.min.js"></script>
<!--script libreria js datatable-->
<script type="text/javascript" src="../datatables/datatables.min.js"></script>

<!--Botón EXCEL,PDF,IMPRIMIR js datattable-->
<script src="../datatables/Buttons-2.3.3/js/dataTables.buttons.min.js"></script>
<script src="../datatables/JSZip-2.5.0/jszip.min.js"></script>
<script src="../datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
<script src="../datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
<script src="../datatables/Buttons-2.3.3/js/buttons.html5.min.js"></script>
<!-- Footer -->
<script type="text/javascript" src="../js/main.js"></script>   
<!---Script Modal Editar--->
<script>
$('.editbtn').on('click',function(){ 
	$tr=$(this).closest('tr');
	var datos=$tr.children("td").map(function(){
		return $(this).text();
	});
$('#update_id').val(datos[0]);
$('#Documento').val(datos[1]);
$('#Nombres').val(datos[2]);
$('#Rol').val(datos[3]);
$('#Idprograma').val(datos[4]);
$('#Nombreprograma').val(datos[5]);
$('#Correo').val(datos[6]);
});
</script>

<!---Script Modal Eliminar--->
<script>
$('.deletebtn').on('click',function(){ 
	$tr=$(this).closest('tr');
	var datos=$tr.children("td").map(function(){
		return $(this).text();
	});
  $('#delete_id').val(datos[0]);
});
</script>
       
<!--conexion de los Datatable-->
<script>
  $(document).ready(function(){
    $('#usuarios').DataTable();    
  });  
  </script> 
        </body>
</html>
