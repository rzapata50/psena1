<!--formato de HTML-->
<!Doctype html>
<html lang="es">
    <head>
        <title>Formulario de Ingreso</title>
        <link rel="shortcut icon" href="../img/icono1.png">
        <!--conexion bootstrap-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
        <!--alerta de formulario--> 
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <!--contenedor de navbar-->
    <body>        
    <nav class="navbar  navbar-expand-lg bg-success">      
  <div class="container-fluid">
    <img src="../img/icono1.png" width="5%">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active text-white" aria-current="page" href="http://localhost/psena/vista/fingreso.php">Inicio</a>
          </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="listado.php">Listado</a>
        </li>
        <!--menu desplegable--
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>-->
        <li class="nav-item">
          <a class="nav-link text-white" href="fingreso.php">Registrarse</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="fconsulta.php">Consulta</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="Buscar" placeholder="Buscar" aria-label="Search">
        <button class="btn btn-outline-success bg-dark" type="submit">Buscar</button>
      </form>
    </div>
  </div>
</nav><br>
<center><br>
<div id="container">
    <h3 class="dsiplay-7 text-dark">Consulta de Usuarios Registrados</h3>
    <form action="" method="post">
        <table>
            <!--tr son las columnas-->
            <tr>
                <!--td son las filas-->
                    <td><label>Digite su número de documento</label><br><br>
                        <input type="text" name="ConsultaDocumento" class="form-control" style="width: 100%">
                    </td>
            </tr><br>   
             <!--estilo de la tabla-->
                <td colspan="2"><br><center>
                    <input type="submit" name="btn_consultar" value="Consultar" class="btn btn-danger">
                    </center>
                </td>            
        </table>
        <td colspan="2"></td>
        <br>

        <!--modulo de consulta-->   
        <?php
        include("../modelo/conexionadd.php");
        if(isset($_POST['btn_consultar']))
        {
            $documento = $_POST['ConsultaDocumento'];
            $existe = 0;

            if($documento=="")
            {
                echo "<script> Swal.fire('Digite un numero de documento para iniciar la consulta')</script>";
            }

            else{
                $resultado = mysqli_query($conectar, "SELECT * FROM registro WHERE documento = '$documento'");

                while($consulta = mysqli_fetch_array($resultado))
                {
                    echo " 
                    <center><table width=\"80%\border\"1\">
                    <tr>
                    <td><center><b>documento</b></center></td>
                    <td><center><b>nombres</b></center></td>
                    <td><center><b>rol</b></center></td>
                    <td><center><b>Id_Programa</b></center></td>
                    <td><center><b>NombrePrograma</b></center></td>
                    <td><center><b>email</b></center></td>
                    </tr>
                    <tr>
                    <td><center>".$consulta['Documento']."</center></td>
                    <td><center>".$consulta['Nombres']."</center></td>
                    <td><center>".$consulta['Rol']."</center></td>
                    <td><center>".$consulta['Id_Programa']."</center></td>
                    <td><center>".$consulta['NombrePrograma']."</center></td>
                    <td><center>".$consulta['Correo']."</center></td>
                    </tr>
                    </table>
                    </center>";
                    
                    $existe++;
                }
                    if($existe==0)
                    {
                        echo "<script> Swal.fire('Número no esta registrado ')</script>";
                    }
            }
        }
        ?>
    </form>
</div>
</center><br>
<br><br>
<br><br>

<!--código de footer final de página-->
<footer class="bg-success text-center text-white">
  <!-- Grid container -->
  <div class="container p-4 pb-0">
    <!-- Section: Social media -->
    <section class="mb-4">
      <!-- Google -->
      <a
        class="btn text-white btn-floating m-1"
        style="background-color: #dd4b39;"
        href="https://www.google.com/intl/es-419/gmail/about/"
        role="button"
        ><i class="fab fa-google"></i>
      </a>           
      <!-- Github -->
      <a
        class="btn text-white btn-floating m-1"
        style="background-color: #333333;"
        href="https://github.com/"
        role="button" 
        ><i class="fab fa-github"></i
      ></a>
    </section>
    <!-- Section: Social media -->
  </div>
  <!-- Grid container -->
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2023 Copyright:
    <a class="text-white">Rafael Ricardo Zapata Cruz - Bogotá, Colombia</a>
  </div>
  <!-- Copyright -->
</footer>

    </body>
</html>
