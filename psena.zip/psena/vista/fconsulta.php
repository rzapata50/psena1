<!--validacion de pagina-->
<?php
session_start();
if (!isset($_SESSION['usuario'])){
  header('location: http://localhost/psena/index.php');
}
?>
<!--formato de HTML-->
<!Doctype html>
<html lang="es">
    <head>
        <title>Consulta</title>
        <link rel="shortcut icon" href="../img/icono1.png">
        <!--conexion bootstrap-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" 
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
        <!--alerta de formulario--> 
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <!--contenedor de navbar-->
    <body>        
    <nav class="navbar  navbar-expand-lg bg-success">      
  <div class="container-fluid">
    <img src="../img/icono1.png" width="5%">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active text-white" aria-current="page" href="../activarpc.php">Inicio</a>
          </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="fingreso.php">Registrarse</a>
        </li>       
        <li class="nav-item">
          <a class="nav-link text-white" href="fconsulta.php">Consulta</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="listado.php">Listado</a>
        </li>
      </ul>      
    </div>
  </div>
</nav><br>
<center><br>
<div id="container">
    <h3 class="dsiplay-7 text-dark">Consulta de Usuarios Registrados</h3>
    <form action="" method="post">
        <table>
            <!--tr son las columnas-->
            <tr>
                <!--td son las filas-->
                    <td><label>Digite su número de documento</label><br><br>
                        <input type="text" name="ConsultaDocumento" class="form-control" style="width: 100%">
                    </td>
            </tr><br>   
             <!--estilo de la tabla-->
                <td colspan="2"><br><center>
                    <input type="submit" name="btn_consultar" value="Consultar" class="btn btn-danger">
                    </center>
                </td>            
        </table>
        <td colspan="2"></td>
        <br>

        <!--modulo de consulta-->   
        <?php
        include("../modelo/conexionadd.php");
        if(isset($_POST['btn_consultar']))
        {
            $documento = $_POST['ConsultaDocumento'];
            $existe = 0;

            if($documento=="")
            {
                echo "<script> Swal.fire('Digite un numero de documento para iniciar la consulta')</script>";
            }

            else{
                $resultado = mysqli_query($conectar, "SELECT * FROM registro WHERE Documento = '$documento'");

                while($consulta = mysqli_fetch_array($resultado))
                {
                    echo " 
                    <center><table width=\"80%\border\"1\">
                    <tr>
                    <td><center><b>Documento</b></center></td>
                    <td><center><b>Nombres</b></center></td>
                    <td><center><b>Rol</b></center></td>
                    <td><center><b>Idprograma</b></center></td>
                    <td><center><b>Nombreprograma</b></center></td>
                    <td><center><b>Correo</b></center></td>
                    </tr>
                    <tr>
                    <td><center>".$consulta['Documento']."</center></td>
                    <td><center>".$consulta['Nombres']."</center></td>
                    <td><center>".$consulta['Rol']."</center></td>
                    <td><center>".$consulta['Idprograma']."</center></td>
                    <td><center>".$consulta['Nombreprograma']."</center></td>
                    <td><center>".$consulta['Correo']."</center></td>
                    </tr>
                    </table>
                    </center>";
                    
                    $existe++;
                }
                    if($existe==0)
                    {
                        echo "<script> Swal.fire('Número no esta registrado ')</script>";
                    }
            }
        }
        ?>
    </form>
</div>
</center><br>
<br><br>
<br><br>

    </body>
</html>
