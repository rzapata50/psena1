<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/icono1.png">
    <title>Equipos</title>
</head>
<body>
    <h1>Equipos de Cómputo</h1>
</body>
</html>