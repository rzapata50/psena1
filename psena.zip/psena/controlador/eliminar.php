<?php
include_once("../modelo/conedit.php");

$id = $_POST['id'];

$sentencia = $bd->prepare("DELETE FROM registro WHERE id=:id;");
$sentencia ->bindParam(':id', $id);

if($sentencia->execute()){

    echo "<script> alert('Datos Eliminados')
    location.href ='../vista/listado.php';</script>";
}

else{
    echo "<script> alert('Error en la Conexión')
    location.href = '../vista/listado.php';</script>";
    
}
?>