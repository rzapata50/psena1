<?php
include_once("../modelo/conedit.php");
$id = $_POST['id'];
$documento = $_POST['Documento'];
$nombre = $_POST['Nombres'];
$rol = $_POST['Rol'];
$idprograma = $_POST['Idprograma'];
$nprograma = $_POST['Nombreprograma'];
$email = $_POST['Correo'];

$sentencia = $bd->prepare("UPDATE registro SET Documento= ?, Nombres= ?, Rol= ?, Idprograma= ?, Nombreprograma= ?, Correo= ? WHERE id= ?;");


$sentencia->execute([$documento, $nombre, $rol, $idprograma, $nprograma, $email, $id]);

if($sentencia){
	
	echo "<script> alert('Actualizada la Información')
	location.href = '../vista/listado.php';</script>";
}
else{
	return "Error";
}
?>