//EQUIPO 1//
let contador = localStorage.getItem("contador");
const display = document.querySelector(".date-display")
const btnStart = document.querySelector(".start")
const btnReset = document.querySelector(".reset")
const btnStop = document.querySelector(".stop")
let interval;
let seconds = 0;

btnStart.addEventListener("click", () =>{
    interval = setInterval(() =>{
        seconds++
        let date = new Date(seconds * 1000)
        let dateStart = date.toISOString().substr(11,8)
        localStorage.setItem("contador",dateStart);
        display.textContent = dateStart
    },1000)
})

btnStop.addEventListener("click", () =>{
    clearInterval(interval)
})

btnReset.addEventListener("click", () =>{
    clearInterval = 0;
    display.textContent = "00:00:00"
    localStorage.removeItem("contador");
})

//EQUIPO 2//
let contador1 = localStorage.getItem("contador1");
const display1 = document.querySelector(".date-display1")
const btnStart1 = document.querySelector(".start1")
const btnReset1 = document.querySelector(".reset1")
const btnStop1 = document.querySelector(".stop1")
let interval1;
let seconds1 = 0;

let intervalo = btnStart1.addEventListener("click", () =>{
    interval1 = setInterval(() =>{
        seconds1++
       
        let date = new Date(seconds1 * 1000)
        let dateStart1 = date.toISOString().substr(11,8)
        localStorage.setItem("contador1",dateStart1);
        display1.textContent = dateStart1
    },1000)
})

btnStop1.addEventListener("click", () =>{
    clearInterval(intervalo)

})

btnReset1.addEventListener("click", () =>{
    clearInterval = intervalo;
    display1.textContent = "00:00:00"
    localStorage.removeItem("contador1");
})