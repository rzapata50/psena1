'use strict'

let contador = localStorage.getItem("contador");
let valor = document.getElementById("mostrar");
let rset = document.getElementById("resetear");

let intervalo = setInterval(()=>{
contador++
localStorage.setItem("contador",contador);
valor.textContent = contador;
},1000)

rset.addEventListener("click",()=>{
    console.log("diste click")
    
    setTimeout(() => {
       clearInterval(intervalo);
       console.log("detenido"); 
        localStorage.removeItem("contador");
        valor.textContent = 0;
     }, 1000);
})
