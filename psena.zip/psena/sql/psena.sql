-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 16-09-2023 a las 19:47:48
-- Versión del servidor: 8.0.31
-- Versión de PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `psena`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facultad`
--

DROP TABLE IF EXISTS `facultad`;
CREATE TABLE IF NOT EXISTS `facultad` (
  `Idfacultad` int NOT NULL,
  `Nombrefacultad` varchar(45) NOT NULL,
  PRIMARY KEY (`Idfacultad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `facultad`
--

INSERT INTO `facultad` (`Idfacultad`, `Nombrefacultad`) VALUES
(1, 'Ciencias de la Salud'),
(2, 'Ingenieria'),
(3, 'Bellas Artes'),
(4, 'Planta Administrativa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `programa`
--

DROP TABLE IF EXISTS `programa`;
CREATE TABLE IF NOT EXISTS `programa` (
  `Idprograma` int NOT NULL,
  `Nombreprograma` varchar(30) NOT NULL,
  `Idfacultad` int NOT NULL,
  `Nombrefacultad` varchar(45) NOT NULL,
  PRIMARY KEY (`Idprograma`),
  KEY `Idfacultad` (`Idfacultad`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `programa`
--

INSERT INTO `programa` (`Idprograma`, `Nombreprograma`, `Idfacultad`, `Nombrefacultad`) VALUES
(1, 'Entrenamiento Deportivo', 1, 'Ciencias de la Salud'),
(4, 'Administrativo', 4, 'Planta Administrativa'),
(10, 'Enfermeria', 1, 'Ciencias de la Salud'),
(20, 'Ingenieria de Sistemas', 2, 'Ingenierias');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

DROP TABLE IF EXISTS `registro`;
CREATE TABLE IF NOT EXISTS `registro` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Documento` int NOT NULL,
  `Nombres` text NOT NULL,
  `Rol` text NOT NULL,
  `Idprograma` int NOT NULL,
  `Nombreprograma` varchar(30) NOT NULL,
  `Correo` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Id_Programa` (`Idprograma`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `registro`
--

INSERT INTO `registro` (`id`, `Documento`, `Nombres`, `Rol`, `Idprograma`, `Nombreprograma`, `Correo`) VALUES
(29, 12345678, 'ricardo zapata', 'Docente', 10, 'Enfermeria', 'exito@correo.com'),
(30, 1023880592, 'Miguel Zapata', 'Egresado', 20, 'Ingenieria de Sistemas', 'miguel18@hotmail.com'),
(32, 1023880593, 'Oscar Pérez', 'Administrativo', 4, 'Administrativo', 'operez@gmail.com'),
(34, 1023880597, 'Rafael Cruz', 'Administrativo', 4, 'Administrativo', 'rcruz@correo.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `idusuario` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `contrasena` varchar(8) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `usuario`, `contrasena`) VALUES
(1, 'admin@creaconexion.com', '12345678'),
(2, 'rafael@creaconexion.com', '123');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `programa`
--
ALTER TABLE `programa`
  ADD CONSTRAINT `programa_ibfk_1` FOREIGN KEY (`Idfacultad`) REFERENCES `facultad` (`Idfacultad`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `registro`
--
ALTER TABLE `registro`
  ADD CONSTRAINT `registro_ibfk_1` FOREIGN KEY (`Idprograma`) REFERENCES `programa` (`Idprograma`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
