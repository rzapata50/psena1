<!--validacion de pagina-->
<?php
session_start();
if (!isset($_SESSION['usuario'])){
  header('location: index.php');
}
?>

<!DOCTYPE html>
<html>
  <head>      
      <meta charset="utf-8">    
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Activar PC</title>
      <link rel="stylesheet" href="css/stylepc.css"> 
      <link rel="shortcut icon" href="img/icono1.png">
          
  </head>
  <!--EQUIPO 1-->
  <body>
    <h1>Préstamo de Equipos</h1>
    <div class="time-container">
        <label1>Equipo 1</label1>
      <div class="date-display">00:00:00</div>
      <br>
      <div class="time">
        <button class="btn start">START</button>
        <button class="btn stop">STOP</button>
        <button class="btn reset">RESET</button>
      </div>       
    </div>
    <!--EQUIPO 2-->
    <div>
      <div class="time-container1">
        <label2>Equipo 2</label2>
        <div class="date-display1">00:00:00</div>
        <br> 
        <div class="time1">
          <button class="btn1 start1">START</button>
          <button class="btn1 stop1">STOP</button>
          <button class="btn1 reset1">RESET</button>
        </div>       
      </div>        
    </div> 
    <!--BOTONES-->
    <div class="container">
      <div class="buttons">
        <a href="cerrarsesion.php" class="btn btn-2">Cerrar Sesión</a>         
        <a href="vista/fingreso.php"class="btn btn-3">Registros</a>
      </div>
    </div>

    <script src="js/script.js"></script>
    
  </body>  
</html>        
        
            
            
                
                
                   
                       
           
      
               


	    
   
